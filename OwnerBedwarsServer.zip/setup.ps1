# Owner Bedwars server - one-click setup and start (Windows)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$ua = @{ 'User-Agent' = 'OwnerPowers-setup/1.0 (personal server)' }
function Say($m, $c = 'Yellow') { Write-Host $m -ForegroundColor $c }

Say "=== Owner Bedwars Server ===" 'Cyan'

# ---------- 1. Java 25 (portable, inside this folder, no admin needed) ----------
$java = Get-ChildItem "$root\java" -Recurse -Filter java.exe -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $java) {
    Say "Downloading Java 25 (one time, ~50 MB)..."
    $zip = "$root\java25.zip"
    Invoke-WebRequest -Headers $ua -Uri 'https://api.adoptium.net/v3/binary/latest/25/ga/windows/x64/jre/hotspot/normal/eclipse?project=jdk' -OutFile $zip
    Expand-Archive $zip "$root\java" -Force
    Remove-Item $zip
    $java = Get-ChildItem "$root\java" -Recurse -Filter java.exe | Select-Object -First 1
}
$javaExe = $java.FullName
Say "Java ready." 'Green'

# ---------- 2. Paper server (newest Minecraft version) ----------
if (-not (Test-Path "$root\paper.jar")) {
    try {
        Say "Finding the newest Paper version..."
        $proj = Invoke-RestMethod -Headers $ua 'https://fill.papermc.io/v3/projects/paper'
        $all = @()
        foreach ($fam in $proj.versions.PSObject.Properties) { $all += $fam.Value }
        $all = $all | Where-Object { $_ -match '^\d+\.\d+(\.\d+)?$' } |
            Sort-Object { [version]($(if ($_ -match '^\d+\.\d+$') { "$_.0" } else { $_ })) } -Descending
        $got = $false
        foreach ($v in $all) {
            try {
                $b = Invoke-RestMethod -Headers $ua "https://fill.papermc.io/v3/projects/paper/versions/$v/builds/latest"
                $url = $b.downloads.'server:default'.url
                if ($url) {
                    Say "Downloading Paper $v..."
                    Invoke-WebRequest -Headers $ua -Uri $url -OutFile "$root\paper.jar"
                    Set-Content "$root\mc-version.txt" $v
                    $got = $true; break
                }
            } catch { }
        }
        if (-not $got) { throw 'no build found' }
    } catch {
        Say "Couldn't download Paper automatically." 'Red'
        Say "Your browser will open the Paper download page. Download the newest Paper jar," 'Red'
        Say "save it in this folder as  paper.jar  and run START-SERVER.bat again." 'Red'
        Start-Process 'https://papermc.io/downloads/paper'
        Read-Host 'Press Enter to close'; exit 1
    }
}
$mcv = if (Test-Path "$root\mc-version.txt") { (Get-Content "$root\mc-version.txt").Trim() } else { '' }
Say "Paper ready $mcv" 'Green'

# ---------- 3. Plugins ----------
New-Item -ItemType Directory -Force "$root\plugins" | Out-Null
if (-not (Get-ChildItem "$root\plugins" -Filter 'BedWars*.jar' -ErrorAction SilentlyContinue)) {
    Say "Downloading Screaming BedWars..."
    $vers = Invoke-RestMethod -Headers $ua 'https://api.modrinth.com/v2/project/screamingbedwars/version?loaders=%5B%22paper%22%5D'
    $pick = $vers | Where-Object { $mcv -and ($_.game_versions -contains $mcv) } | Select-Object -First 1
    if (-not $pick) { $pick = $vers | Select-Object -First 1 }
    $f = $pick.files | Where-Object { $_.primary } | Select-Object -First 1
    if (-not $f) { $f = $pick.files[0] }
    Invoke-WebRequest -Headers $ua -Uri $f.url -OutFile "$root\plugins\$($f.filename)"
    Say "BedWars $($pick.version_number) installed." 'Green'
}
if (Test-Path "$root\OwnerPowers.jar") { Move-Item "$root\OwnerPowers.jar" "$root\plugins\OwnerPowers.jar" -Force }

# ---------- 4. Owner name ----------
$cfgDir = "$root\plugins\OwnerPowers"
if (-not (Test-Path "$cfgDir\config.yml")) {
    New-Item -ItemType Directory -Force $cfgDir | Out-Null
    $name = ''
    while ($name -notmatch '^[A-Za-z0-9_]{3,16}$') { $name = Read-Host 'Type YOUR Minecraft username (you become the owner)' }
    $cfg = (Get-Content "$root\owner-config-template.yml" -Raw -Encoding UTF8).Replace('owner: ""', "owner: `"$name`"")
    [IO.File]::WriteAllText("$cfgDir\config.yml", $cfg, (New-Object Text.UTF8Encoding $false))
    Say "Owner set to $name." 'Green'
}

# ---------- 5. EULA (you must accept it yourself) ----------
if (-not (Select-String -Path "$root\eula.txt" -Pattern 'eula=true' -Quiet -ErrorAction SilentlyContinue)) {
    Say "Minecraft servers require accepting the Minecraft EULA: https://aka.ms/MinecraftEULA" 'Cyan'
    $a = Read-Host 'Do you accept the Minecraft EULA? Type YES'
    if ($a -ne 'YES') { Say 'Not accepted, server will not start.' 'Red'; Read-Host 'Press Enter to close'; exit 1 }
    Set-Content "$root\eula.txt" 'eula=true'
}

# ---------- 6. Server settings (first run only) ----------
if (-not (Test-Path "$root\server.properties")) {
    @(
        'motd=\u00a76\u00a7lOwner Bedwars \u00a77- \u00a7cmeteors incoming',
        'level-type=minecraft\:flat',
        'allow-flight=true',
        'spawn-protection=0',
        'gamemode=survival',
        'difficulty=normal',
        'max-players=20',
        'online-mode=true',
        'enable-command-block=true'
    ) | Set-Content "$root\server.properties" -Encoding ASCII
}

# ---------- 7. Start ----------
Say ""
Say "Starting the server. When you see 'Done', open Minecraft > Multiplayer > Direct Connection > localhost" 'Cyan'
Say "Type  stop  in this window to shut it down safely." 'Cyan'
& $javaExe -Xms2G -Xmx4G -jar paper.jar --nogui
Read-Host 'Server stopped. Press Enter to close'
