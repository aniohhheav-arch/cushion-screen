OWNER BEDWARS SERVER - QUICK START (Windows)
=============================================

1. Extract this zip somewhere easy, e.g. Desktop\Minecraft Owner Server
2. Double-click START-SERVER.bat
   - First run downloads Java 25, Paper (newest Minecraft) and Screaming BedWars.
   - It asks for YOUR Minecraft username (that makes you the owner).
   - It asks you to accept the Minecraft EULA (type YES).
   - If Windows SmartScreen warns you, click "More info" > "Run anyway".
3. When the window says "Done", open Minecraft > Multiplayer >
   Direct Connection > type  localhost  > Join.
4. In game, type  /powers  to see everything. Type  /tools  for the special tools.
   Type  stop  in the server window to shut down safely.

FRIENDS ON THE SAME WIFI: they join with your PC's local IP (run "ipconfig", look for IPv4).
Over the internet needs port forwarding (port 25565) or a tunnel like playit.gg.

OWNER COMMANDS (nobody else can use them)
  /fly /god /jump /strength /nightvision /vanish /instamine   toggles
  /allpowers on|off      /speed 1-10     /heal    /gm c|s|a|sp   /day /night
  /meteor                meteor strike where you look
  /meteor shower         a shower of meteors
  /armageddon            30 meteors raining all around you
  /smite <player>        triple lightning      /yeet <player>   launch into the sky
  /tools                 Thor's Hammer, Meteor Staff, Blink Wand, Fireball Staff,
                         Omega Pickaxe, Rocket Feather, Owner Blade
  Perks: auto-op (all vanilla cheats), everyone else is de-opped, [OWNER] tag,
  keep inventory, immune to fall/fire/lightning/explosions.

ADMIN / UPDATE COMMANDS (also work from the host's web console without the slash)
  /adminabuse [seconds]  /adminabuse stop     free loot, meteor show, buffs for everyone
  /privatemode on|off    /privatemode add <name>   only you + testers can join
  /unleash [seconds]     countdown, then restart so a new plugin version goes live
  /setlobby  /buildlobby  /lobby (everyone)

FRIENDS (everyone): /friend add|accept|deny|remove|list|msg  -  /friends opens the menu
PRIVATE LOBBY: nobody sees anybody in the main lobby; BedWars lobbies show everyone.
JOIN CINEMATIC: cloud-break dive at midnight into sunrise (first join full, regulars short). Hold SPACE or sneak to skip. /intro replays it. Turn off: intro.enabled: false

LOBBY: a floating island is built automatically at 0,120,0 on first start, with a
fountain, holograms, a BedWars NPC, a game-menu compass, scoreboard and double jump.
Build BedWars arenas at least 100 blocks away from it (or in another world).
Set your address for the scoreboard in plugins\OwnerPowers\config.yml (server-address).

Meteors don't break blocks by default (so your lobby and maps survive).
To change: plugins\OwnerPowers\config.yml  ->  meteor-breaks-blocks: true

RESOURCE PACK (custom 3D artifacts, HUD, sounds) - needed for the Apocalypse Core
  1. Go to https://mc-packs.net and upload OwnerPowersPack.zip
  2. Copy the "direct download" link it gives you
  3. Paste it into plugins\OwnerPowers\config.yml  ->  resource-pack: url: "<link>"
     (the sha1 is already filled in for this exact zip; if you change the zip, use the new SHA-1 mc-packs shows)
  4. Restart. Everyone gets asked to download the pack when they join.

APOCALYPSE CORE: /arsenal (or Sneak+F) -> take the core -> right-click where you want the meteor.

MYTHIC ARTIFACTS (need the resource pack)
  GRIMOIRE OF CHAOS   right-click: Arcane Ray   sneak+right-click: Spell Barrage
  FROST CROWN         right-click: Absolute Zero (freezing wave, ice spikes, enemies frozen 3s)
  INFERNAL HEART      right-click where you look: Worldbreaker (volcano, fire pillars, lava waves)
  SOUL REAVER         right-click: Wraith Summoning (4 guardians, ghostly shockwave)
  INFINITY CUBE       right-click where you look: Reality Collapse (glitch zone + pulse)
  CHRONOS HOURGLASS   right-click: Time Reversal (slow field, then rewind enemies)
  PHANTOM WINGS       right-click: Ascension (8s flight); right-click again in the air: Divine Descent
  SOLAR NUCLEUS       keep it in your inventory and a miniature sun follows you
                      right-click: Solar Ray   sneak+right: Solar Burst
                      left-click: Corona        sneak+left: Supernova
  OMNISIGHT           right-click: Eye of Creation (reveal everyone in 48 blocks, tracking eyes, main beam)
  MIRROR SHARD        right-click: Dimension of Reflections (mirror walls, invisibility, 5 clones)
  WORLDSEED           right-click where you look: Nature's Wrath (roots snare, forest burst)
  VOID ENGINE         right-click where you look: Mechanical Apocalypse (walker, barrier, lasers)
  Get them from /arsenal (or Sneak+F). Cooldowns and damage: plugins\OwnerPowers\config.yml

THE SONATA - God of Sound (owner exclusive)
  left-click: switch ability    right-click: perform it
    Bass Drop / Note Storm / Reverb (sound dome, blocks fireballs) / Arpeggio / Symphony of Chaos
  sneak (just hold it): inspect the synth
  sneak+right-click: LIVE PERFORMANCE - hotbar keys 1-9 play notes (1-2 bass, 3-9 melody),
    left-click = octave, right-click = chord, sneak+right-click or Q = exit

EYE OF ETERNITY (Tsukuyomi) - exclusive to Yoav
  Bind it once (console or owner):  bindmythic eye <YoavMinecraftName>
  Yoav gets it back any time with /eye. Look at an opponent (any distance) and right-click.

BEDWARS ARENA SETUP (in game, once you've built or loaded a map)
  /bw admin <arena> add
  /bw admin <arena> pos1          (stand at one corner)
  /bw admin <arena> pos2          (opposite corner)
  /bw admin <arena> team add Red RED 1      (repeat for each team)
  /bw admin <arena> team spawn Red          (stand on the spawn)
  /bw admin <arena> team bed Red            (look at the bed)
  /bw admin <arena> spawner add <resource> true
  /bw admin <arena> store add
  /bw admin <arena> lobby         (waiting lobby)
  /bw admin <arena> spec
  /bw admin <arena> save
  Players join with  /bw join <arena>
  Full docs: https://docs.screamingsandals.org
